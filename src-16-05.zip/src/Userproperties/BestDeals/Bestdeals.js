import React from 'react'

const UserBestdeals = () => {
  return (
    <div>Bestdeals</div>
  )
}

export default UserBestdeals