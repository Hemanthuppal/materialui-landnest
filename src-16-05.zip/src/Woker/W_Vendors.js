import React from 'react'

const W_Vendors = () => {
  return (
    <div>W_Vendors</div>
  )
}

export default W_Vendors